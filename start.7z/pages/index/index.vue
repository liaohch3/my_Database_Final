<template>
	<view class="page">
		
		<!-- 轮播图 -->
		<swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" class="carousel">
			<swiper-item v-for="(car, carIndex) in carouselList" :key="carIndex">
				<image :src="car.url" class="carousel"></image>
			</swiper-item>
		</swiper>
		
		<!-- 热门球员 -->
		<view class="page-block super-hot">
			<view class="hot-title-wapper">
				<image src="../../static/icon/remen.png" class="hot-icon"></image>
				<view class="hot-title">
					热门球队
				</view>
			</view>
		</view>
		
		<scroll-view scroll-x="true" class="page-block hot">
			<view class="single-poster" v-for="(scr, scrIndex) in scrollList" :key="scrIndex">
				<view class="poster-wapper">
					<image :src="scr.url" class="poster"></image>
					<view class="team-name">
						{{scr.name}}
					</view>
				</view>
			</view>
		</scroll-view>
		
	</view>
</template>

<script>
	import common from "../../common/common.js";
	var serverUrl = common.serverUrl;
	
	export default {
		data() {
			return {
				carouselList: [],
				scrollList: [],
				imageUrl: "https://ws1.sinaimg.cn/large/007RvR0Hgy1ga934esikgj3046046dft.jpg"
			}
		},
		onLoad() {
			var me = this;
			console.log("---------------------");
			console.log(serverUrl);
			console.log("=====================");
			
			uni.request({
				url: serverUrl + '/api/image',
				method: 'GET',
				success: (res) => {
					if(res.statusCode == 200){
						var tempCar = res.data.data; 
						// console.log(tempCar);
						me.carouselList = tempCar;
					}
				},
				fail: () => {
					console.log("请求失败。。。");
				},
				complete: () => {}
			});
			
			uni.request({
				url: serverUrl + '/api/team',
				method: 'GET',
				success: (res) => {
					if(res.statusCode == 200){
						var tempScr = res.data.data; 
						console.log(tempScr);
						me.scrollList = tempScr;
					}
				},
				fail: () => {
					console.log("请求失败。。。");
				},
				complete: () => {}
			});
		},
		methods: {
			
		}
	}
</script>

<style>
	@import url("index.css");
</style>
