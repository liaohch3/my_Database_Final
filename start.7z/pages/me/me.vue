<template>
	<view class="">

		<!-- #ifdef MP -->
		
		<van-cell-group>
			<van-field required label="姓名" :value="name" placeholder="请输入姓名" @change="changeName" border="false"></van-field>
			
			<van-field required type=number  label="身高" :value="height" placeholder="请输入身高(米)" @change="changeHeight" border="false"></van-field>
			<van-field required label="体重" :value="weight" placeholder="请输入体重(千克)" @change="changeWeight" border="false"></van-field>
			<van-field required label="位置" :value="pos" placeholder="请输入位置" @focus="showPopup"></van-field>
			<van-popup :show="isShow" custom-style="height: 40%" closeable close-icon="close" position="bottom" @close="onClose">
				<van-picker show-toolbar title="位置" :columns="positions" @cancel="onClose" @confirm="changePos"></van-picker>
			</van-popup>
			<van-field label="号码" :value="num" placeholder="请输入号码" @change="changeNum" border="false"></van-field>
			<van-popup :show="isError" custom-style="height: 20%" @close="onClose">请输入有效信息</van-popup>
		</van-cell-group>
		<van-cell></van-cell>
		<van-button type="danger" size="large" @click="addData">即刻安排</van-button>
		<!-- #endif -->
		</view>
</template>

<script>
	export default {
		data() {
			return {
				checked: true,
				name: '',
				height: '',
				weight: '',
				pos: '',
				num: '',
				isShow: false,
				positions: ['PG','SG','SF','PF','C'],
				nickName: '',
				openid: '',
				session_key: '',
			}
		},
		onLoad() {
			var me = this; 
			var res = global.isLogin();
			if(!res){
				uni.showModal({
					title: '提醒',
					content: "请登录",
					success:function(){
						uni.navigateTo({
							url:"/pages/login/login"
						});
						uni.$once('update',function(data){
							me.nickName = data.nickName;
							me.openid = data.openid;
							me.session_key = data.session_key;
							// console.log('我是', me.nickName);
							// console.log('我是', me.openid);
							// console.log('我是', me.session_key);
							// console.log('监听到事件来自 update ，携带参数 msg 为：' + data.nickName);
						}); 
					},
					
				});
			}
		},
		
		methods: {
		
			
		addData:function() {
			var me = this;
			
			if (me.pos=='' || isNaN(parseInt(me.height)) || isNaN(parseInt(me.weight)) || parseInt(me.height) < 100 || parseInt(me.height) > 300 || parseInt(me.weight) < 35 || parseInt(me.weight) > 200) {
				me.isError = true;
				return 0;
			}
			if (me.num=='') {
				me.num=='0'
			}
			
			const db = wx.cloud.database();
			const projectCollection = db.collection('DBproject');
			
			console.log('me.nickName', me.nickName);
			console.log('me.openid', me.openid);
			console.log('me.session_key', me.session_key);
			console.log('me.height', parseInt(me.height));
			
			projectCollection.add({
				data: {
					nickName: me.nickName,
					openid:me.openid,
					session_key:me.session_key,
					name: me.name,
					height: parseInt(me.height),
					weight: parseInt(me.weight),
					pos: me.pos,
					num: me.num
				}
			});
			success:res => {
				console.log(res);
				console.log('-----------------');
			};
			fail:res =>{
				console.log("失败", res);
			};
			
			console.log("+++++++++++++++++++++++");
		},
		changeName:function(event){
			this.name = event.detail;
			// console.log(event);
			// console.log(this.height);
		},
		changeHeight:function(event){
			this.height = event.detail;
			// console.log(event);
			// console.log(this.height);
		},
		changeWeight:function(event){
			this.weight = event.detail;
			// console.log(event);
			// console.log(this.weight);
		},
		changePos:function(event){
			this.pos = event.detail.value;
			console.log(event);
			console.log(this.pos);
			this.isShow = false;
			// console.log(this.weight);
		},
		changeNum:function(event){
			this.num = event.detail;
			// console.log(event);
			// console.log(this.height);
		},
		showPopup:function() {
			this.isShow = true;
			console.log(this.isShow);
		},
		onClose:function() {
			this.isShow = false;
			console.log(this.isShow);
		},
		 onChange:function(event) {
			this.checked = !this.checked;
		  }		
		}
	}
</script>

<style>

</style>
